"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express = require("express");
var platform_1 = require("../models/platform");
var router = express.Router();
router.get('/', function (req, res) {
    platform_1.default.find({}, function (err, result) {
        console.log(result);
        res.json(result);
    });
});
exports.default = router;
