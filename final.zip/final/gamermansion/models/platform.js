"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mongoose = require("mongoose");
var platformSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    games: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Games' }]
});
exports.default = mongoose.model('Platform', platformSchema);
