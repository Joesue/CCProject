var gamermansion;
(function (gamermansion) {
    var Services;
    (function (Services) {
        var GameService = (function () {
            function GameService($resource) {
                this.$resource = $resource;
                this.GameResource = $resource('/games/:id');
            }
            GameService.prototype.saveGame = function (game) {
                this.GameResource.save(game);
            };
            GameService.prototype.findPlatformGames = function (platform) {
                return this.GameResource.query({ id: platform }).$promise;
            };
            GameService.prototype.getAllGames = function () {
                return this.GameResource.query();
            };
            GameService.prototype.removeGame = function (id) {
                this.GameResource.delete({ id: id });
            };
            return GameService;
        }());
        Services.GameService = GameService;
        var PlatformService = (function () {
            function PlatformService($resource) {
                this.$resource = $resource;
                this.PlatformResource = $resource('/platforms');
            }
            PlatformService.prototype.getAllPlatforms = function () {
                return this.PlatformResource.query();
            };
            return PlatformService;
        }());
        Services.PlatformService = PlatformService;
        var UserService = (function () {
            function UserService($resource) {
                this.$resource = $resource;
                this.LoginResource = this.$resource('/userRoutes/api/Login/Local');
                this.SignUpResource = this.$resource('/userRoutes/api/Register');
            }
            UserService.prototype.registerUser = function (userObj) {
                return this.SignUpResource.save(userObj).$promise;
            };
            UserService.prototype.loginUser = function (userInfo) {
                return this.LoginResource.save(userInfo).$promise;
            };
            return UserService;
        }());
        Services.UserService = UserService;
        angular.module('gamermansion').service('gameService', GameService);
        angular.module('gamermansion').service('platformService', PlatformService);
        angular.module('gamermansion').service('userService', UserService);
    })(Services = gamermansion.Services || (gamermansion.Services = {}));
})(gamermansion || (gamermansion = {}));
