namespace gamermansion.Controllers {

    export class HomeController {
      public games;
      public game;
      public payload;
      public platforms;
      public selectedPlatform;
      public searching;
      public platform;
      public searchComplete;
      public foundGames;

      public deleteGame(id) {
        if(this.payload.role === 'admin') {
          this.gameService.removeGame(id);
          alert('Success!');
          this.$state.reload();
        } else {
          alert('Denied. admins only.')
        };

        //this.gameService.removeGame(id);
      }

      public pickFile() {
        this.filepickerService.pick(
          {mimetype: 'image/*'},
          this.fileUploaded.bind(this)
        );
      }

      public fileUploaded(game) {
        this.game = game;

        this.$scope.$apply();
      }

      public findGames() {
        this.searching = true;
        this.gameService.findPlatformGames(JSON.parse(this.selectedPlatform).name).then((result) => {
          console.log(result);
          this.games = result;
          this.searching = false;
        });
      }

      public constructor(
        private gameService, private filepickerService, private $scope: ng.IScope, public $state, private platformService
      ) {
        this.games = this.gameService.getAllGames();
        this.platforms = this.platformService.getAllPlatforms();
        let token = window.localStorage['token'];
        console.log(this.platforms)

        if(token) {
          this.payload= JSON.parse(window.atob(token.split('.')[1]));
          console.log(this.payload);
        }
      }

    }


    export class AddGamesController {
        public game;
        public payload;

        public addGame(photo) {
          if(this.payload.role === 'admin') {
            this.game.photo = photo.url;
            this.gameService.saveGame(this.game);
            alert('Success!');
            this.$state.go('home')
          } else {
            alert('Denied. admins only.');

          }
          //this.gameService.saveGame(this.game);
        }


        public pickFile() {
          this.filepickerService.pick(
            {mimetype: 'image/*'},
            this.addGame.bind(this)
          );
        }

        public fileUploaded(game) {
          this.game = game;

          this.$scope.$apply();
        }


        constructor(
          private gameService, private filepickerService, private $scope: ng.IScope, public $state
        ) {
          let token = window.localStorage['token'];

          if(token) {
            this.payload = JSON.parse(window.atob(token.split('.')[1]));
            console.log(this.payload);
          }

        }
    }

    export class EditGamesController{
      public game;
      public id;
      public payload;

      public editGame() {
        if(this.payload.role === 'admin') {
          this.game._id = this.id;
          this.gameService.saveGame(this.game);
          alert('Success');
        } else {
          alert('Denied. admins only.');
        };
        this.$state.go('home')

        //this.game._id = this.id;
        //this.gameService.saveGame(this.game);
      }

      public pickFile() {
        this.filepickerService.pick(
          {mimetype: 'image/*'},
          this.fileUploaded.bind(this)
        );
      }

      public fileUploaded(photo) {
        this.game.url = photo.url;

        this.$scope.$apply();

        this.editGame();
      }




      public constructor(
        public $stateParams,
        private gameService,
        private filepickerService,
        private $scope: ng.IScope,
        public $state
      ) {
        this.id = $stateParams['id'];
        let token = window.localStorage['token'];

        if(token){
          this.payload = JSON.parse(window.atob(token.split('.')[1]));
          console.log(this.payload);
        }
      }

    }

    export class LoginController {
      public userInfo;
      public isAdmin;

      public login() {
        if(this.isAdmin ===true) {
          this.userInfo.role = 'admin';
          this.createSession();
        } else {
          this.userInfo.role = 'guest';
          this.createSession();
        }
      }

      public createSession() {
        this.userService.loginUser(this.userInfo).then((data) => {
          this.$window.localStorage.setItem("token", JSON.stringify(data.token));
          alert('login successful');
          this.$state.go('home');

        })
      }

      public constructor(
        private userService,
        public $window,
        public $state
      ) {

      }

    }


      export class RegisterController {
          public user;

          public signup() {
            this.userService.registerUser(this.user).then(() => {
              alert('signup successful, please login');
              this.$state.go('login')
            })
          }

          public constructor(
            private userService,
            public $state
          ) {

          }
      }

      export class AboutController {


      }



}
